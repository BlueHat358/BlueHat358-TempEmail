// src/pages/about.js — Halaman About/FAQ
import { baseLayout, escapeHtml } from "../theme.js";
import {
  EMAIL_TTL_DAYS,
  ATTACHMENT_TTL_DAYS,
  MAX_EMAILS_PER_INBOX,
  MAX_ATTACHMENT_SIZE_MB,
  RATE_LIMITS,
} from "../config.js";

export function renderAboutPage({ domains = [], domain = "", nonce = "" } = {}) {
  const currentDomain = domain || domains[0] || "bluehat358.pp.ua";

  // Nilai dari config — tampil di FAQ & tabel
  const emailTtl     = EMAIL_TTL_DAYS;
  const attTtl       = ATTACHMENT_TTL_DAYS;
  const maxEmails    = MAX_EMAILS_PER_INBOX;
  const maxAttMB     = MAX_ATTACHMENT_SIZE_MB;
  const rlPage       = RATE_LIMITS.page;
  const rlApi        = RATE_LIMITS.api;
  const rlDelete     = RATE_LIMITS.delete;

  const body = `
    <!-- Header -->
    <div style="margin-bottom: 2.5rem;">
      <div style="display:flex;align-items:center;gap:0.75rem;margin-bottom:0.5rem;">
        <a href="/" style="color:var(--subtext);font-size:0.85rem;text-decoration:none;">← Beranda</a>
      </div>
      <h1 style="font-size:2rem;margin-bottom:0.5rem;">
        Tentang <span style="color:var(--accent)">BlueHat358</span> TempMail
      </h1>
      <p style="color:var(--subtext);font-size:1rem;font-family:'Space Grotesk',sans-serif;">
        Layanan email sementara serverless berbasis Cloudflare Workers.
      </p>
    </div>

    <!-- Two-column layout -->
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:1.5rem;margin-bottom:2rem;" class="about-grid">
      <div class="about-card">
        <div class="about-card-icon">📬</div>
        <h2>Apa itu TempMail?</h2>
        <p>
          BlueHat358 TempMail adalah layanan email sementara — kamu bisa langsung membuat inbox instan
          tanpa mendaftar, tanpa password, tanpa akun. Cocok untuk registrasi di layanan yang ingin kamu
          coba tanpa memberikan email asli.
        </p>
      </div>

      <div class="about-card">
        <div class="about-card-icon">⚙️</div>
        <h2>Cara Kerja</h2>
        <p>
          Setiap nama yang kamu masukkan otomatis menjadi inbox di domain
          <code>@${escapeHtml(currentDomain)}</code>. Tidak ada proses pendaftaran.
          Email masuk langsung disimpan dan bisa dibuka siapapun yang tahu URL-nya.
        </p>
      </div>

      <div class="about-card about-card-warning">
        <div class="about-card-icon">⚠️</div>
        <h2>Privasi — Baca Ini!</h2>
        <p>
          Inbox bersifat <strong>publik sepenuhnya</strong>. Siapa saja yang mengetahui nama inbox kamu
          dapat membaca semua email di dalamnya. <strong>Jangan gunakan</strong> untuk OTP bank, reset
          password akun penting, atau informasi sensitif apapun.
        </p>
      </div>

      <div class="about-card">
        <div class="about-card-icon">🛠️</div>
        <h2>Teknologi</h2>
        <p>
          Dibangun di atas Cloudflare Workers (edge serverless), KV untuk metadata, R2 untuk attachment,
          dan postal-mime untuk parsing MIME. Tidak ada server, tidak ada database tradisional.
        </p>
      </div>
    </div>

    <!-- FAQ -->
    <div style="margin-bottom:2.5rem;">
      <h2 style="font-size:1.4rem;margin-bottom:1.25rem;color:var(--subtext);font-family:'Space Grotesk',sans-serif;">
        ❓ FAQ — Pertanyaan yang Sering Ditanyakan
      </h2>
      <div style="display:flex;flex-direction:column;gap:0.75rem;" id="faq-list">
        ${faqItem("Berapa lama email disimpan?",
          `Email otomatis dihapus setelah <strong>${emailTtl} hari</strong> sejak diterima. Attachment disimpan selama <strong>${attTtl} hari</strong>. Ini tidak bisa diperpanjang.`)}
        ${faqItem("Apakah inbox saya aman?",
          "Tidak sepenuhnya. Inbox hanya seaman nama yang kamu pilih — jika orang lain bisa menebak nama inbox kamu, mereka bisa membaca email kamu. Gunakan nama yang cukup unik untuk mengurangi risiko.")}
        ${faqItem("Berapa batas ukuran attachment?",
          `Maksimal <strong>${maxAttMB} MB per file attachment</strong>. File yang lebih besar akan di-skip (tidak disimpan), tapi info nama dan ukuran file tetap ditampilkan.`)}
        ${faqItem("Berapa banyak email yang bisa masuk?",
          `Maksimal <strong>${maxEmails} email per inbox</strong>. Setelah itu, email lama yang paling tua akan otomatis terhapus (FIFO) saat email baru masuk.`)}
        ${faqItem("Apakah ada tracking atau iklan?",
          "Tidak ada. Tidak ada analytics, tidak ada cookie tracking pihak ketiga, tidak ada iklan. Ini layanan murni berbasis utilitas.")}
        ${faqItem("Apakah bisa menerima email HTML?",
          "Ya. Email HTML di-render dalam iframe yang di-sandbox untuk mencegah XSS. Script dalam email diblokir sepenuhnya.")}
        ${faqItem("Apa itu nama inbox yang valid?",
          "Nama inbox boleh menggunakan huruf kecil (a–z), angka (0–9), titik (.), underscore (_), plus (+), dan tanda hubung (-). Minimal 3 karakter, maksimal 64 karakter. Tidak boleh diawali atau diakhiri simbol, dan tidak boleh ada simbol berurutan (mis: \"..\", \"--\").")}
        ${faqItem("Kenapa email saya tidak muncul?",
          `Periksa: (1) Apakah alamat email sudah benar? (2) Email mungkin tertahan di server pengirim. (3) Inbox mungkin sudah penuh (${maxEmails} email). (4) Coba klik Refresh. Ingat, tidak semua layanan bisa kirim ke domain baru.`)}
        ${faqItem("Apakah bisa mengirim email dari sini?",
          "Tidak. Layanan ini hanya untuk <em>menerima</em> email. Tidak ada fitur kirim email.")}
        ${faqItem("Apakah data saya dilindungi GDPR?",
          `Layanan ini tidak menyimpan data pribadi (tidak ada akun, tidak ada login). Email yang masuk disimpan sementara di Cloudflare KV/R2 dan otomatis dihapus setelah ${emailTtl} hari.`)}
      </div>
    </div>

    <!-- Limits table -->
    <div style="margin-bottom:2.5rem;">
      <h2 style="font-size:1.4rem;margin-bottom:1.25rem;color:var(--subtext);font-family:'Space Grotesk',sans-serif;">
        📊 Batas Sistem
      </h2>
      <div style="overflow-x:auto;">
        <table class="limits-table">
          <thead>
            <tr><th>Parameter</th><th>Nilai</th><th>Keterangan</th></tr>
          </thead>
          <tbody>
            <tr><td>Umur email</td><td><span class="limit-badge">${emailTtl} hari</span></td><td>Auto-hapus oleh KV TTL</td></tr>
            <tr><td>Umur attachment</td><td><span class="limit-badge">${attTtl} hari</span></td><td>R2 cleanup tiap jam + lifecycle rule</td></tr>
            <tr><td>Maks email/inbox</td><td><span class="limit-badge">${maxEmails} email</span></td><td>Email terlama terhapus otomatis (FIFO)</td></tr>
            <tr><td>Maks ukuran attachment</td><td><span class="limit-badge">${maxAttMB} MB</span></td><td>File lebih besar di-skip</td></tr>
            <tr><td>Panjang nama inbox</td><td><span class="limit-badge">3–64 karakter</span></td><td>Huruf kecil, angka, . _ + -</td></tr>
            <tr><td>Rate limit halaman</td><td><span class="limit-badge">${rlPage.max} req/${rlPage.windowSec}d</span></td><td>Per IP</td></tr>
            <tr><td>Rate limit API</td><td><span class="limit-badge">${rlApi.max} req/${rlApi.windowSec}d</span></td><td>Per IP</td></tr>
            <tr><td>Rate limit hapus</td><td><span class="limit-badge">${rlDelete.max} req/${rlDelete.windowSec}d</span></td><td>Per IP</td></tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Cloudflare notice -->
    <div class="about-card" style="display:flex;align-items:center;gap:1rem;flex-wrap:wrap;">
      <div style="font-size:2.5rem;">☁️</div>
      <div>
        <h3 style="margin-bottom:0.3rem;">Ditenagai Cloudflare Workers</h3>
        <p style="color:var(--subtext);font-size:0.875rem;">
          Berjalan di 300+ edge node global. Latensi rendah, tidak ada server sentral yang bisa down.
          Storage di Cloudflare KV (metadata) dan R2 (attachment binary).
        </p>
      </div>
    </div>
  `;

  const head = `
  <style>
    .about-grid { }
    @media(max-width:640px) { .about-grid { grid-template-columns: 1fr !important; } }
    .about-card { background:var(--surface);border:1px solid var(--surface1);border-radius:var(--radius-lg);padding:1.5rem; }
    .about-card-warning { border-color:var(--yellow);background:color-mix(in srgb, var(--yellow) 5%, var(--surface)); }
    .about-card-icon { font-size:1.75rem;margin-bottom:0.75rem; }
    .about-card h2 { font-size:1rem;margin-bottom:0.6rem;font-family:'Space Grotesk',sans-serif; }
    .about-card p { color:var(--subtext);font-size:0.875rem;line-height:1.7; }
    .about-card p code { color:var(--accent);font-family:'JetBrains Mono',monospace;font-size:0.85em; }
    .faq-item { background:var(--surface);border:1px solid var(--surface1);border-radius:var(--radius-md);overflow:hidden;transition:var(--trans); }
    .faq-item:hover { border-color:var(--accent); }
    .faq-question { width:100%;text-align:left;background:transparent;border:none;padding:1rem 1.25rem;font-family:'Space Grotesk',sans-serif;font-size:0.95rem;font-weight:600;color:var(--text);cursor:pointer;display:flex;justify-content:space-between;align-items:center;gap:1rem;transition:var(--trans); }
    .faq-question:hover { color:var(--accent); }
    .faq-arrow { transition:transform 200ms;color:var(--overlay);font-size:0.75rem; }
    .faq-item.open .faq-arrow { transform:rotate(180deg); }
    .faq-answer { max-height:0;overflow:hidden;transition:max-height 300ms ease,padding 200ms ease;padding:0 1.25rem;color:var(--subtext);font-size:0.875rem;line-height:1.7; }
    .faq-item.open .faq-answer { max-height:200px;padding:0 1.25rem 1rem; }
    .limits-table { width:100%;border-collapse:collapse;font-size:0.875rem;background:var(--mantle);border:1px solid var(--surface1);border-radius:var(--radius-md);overflow:hidden; }
    .limits-table th { background:var(--mantle);padding:0.75rem 1rem;text-align:left;color:var(--subtext);font-weight:600;font-size:0.8rem;text-transform:uppercase;letter-spacing:0.05em;border-bottom:1px solid var(--surface1); }
    .limits-table td { padding:0.75rem 1rem;border-bottom:1px solid var(--surface1);color:var(--text); }
    .limits-table tr:last-child td { border-bottom:none; }
    .limits-table tr:hover td { background:var(--surface); }
    .limit-badge { background:var(--surface1);color:var(--accent);padding:0.2rem 0.6rem;border-radius:var(--radius-sm);font-family:'JetBrains Mono',monospace;font-size:0.8rem;white-space:nowrap; }
  </style>`;

  const page = baseLayout({ title: "Tentang & FAQ", head, body, brandDomain: currentDomain, emailTtlDays: EMAIL_TTL_DAYS, nonce });

  return page.replace("</body>", `
<script nonce="${nonce}">
function toggleFaq(el) {
  var item = el.closest('.faq-item');
  var wasOpen = item.classList.contains('open');
  document.querySelectorAll('.faq-item.open').forEach(function(i) { i.classList.remove('open'); });
  if (!wasOpen) item.classList.add('open');
}

// [Fix M-1] CSP nonce-based tidak mengizinkan onclick inline — pakai
// event delegation untuk semua tombol pertanyaan FAQ.
document.addEventListener('click', function(e) {
  var btn = e.target.closest('.faq-question');
  if (btn) toggleFaq(btn);
});
</script>
</body>`);
}

function faqItem(question, answerHtml) {
  return `<div class="faq-item">
    <button class="faq-question">
      <span>${escapeHtml(question)}</span>
      <span class="faq-arrow">▼</span>
    </button>
    <div class="faq-answer">${answerHtml}</div>
  </div>`;
}
